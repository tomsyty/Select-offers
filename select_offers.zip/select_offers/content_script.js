window.addEventListener('load', async () => {
	console.log('Załadowano skrypt selectOffers');
  observeOffersList();
});

function observeOffersList() {
	const observedElement = document.querySelector('table[aria-label="lista ofert"]');
	let previousUrl = '';
  if (observedElement === null) {
		const offersTableObserver = new MutationObserver(mutations => {
			mutations.forEach(mutation => {
				if (mutation.type === 'childList') {
					if (Array.from(mutation.addedNodes).find(element => element.nodeName === 'DIV' && element.querySelector('table[aria-label="lista ofert"]'))) {
						offersTableObserver.disconnect();
						observeOffersList();
					}
				}
			});
		});
		offersTableObserver.observe(document, { subtree: true, childList: true });
  } else {
    const urlObserver = new MutationObserver(() => {
      if (window.location.href !== previousUrl) {
        previousUrl = window.location.href;
        const delay = t => new Promise(resolve => setTimeout(resolve, t));
        delay(100).then(() => {
          attachEventToOffersList();
        });
        return;
      }
    });
    urlObserver.observe(document, {	subtree: true, childList: true });
  }
}

async function waitForMyAssortmentReady() {
  const offersTable = document.querySelector('table[aria-label="lista ofert"]');
  if (offersTable === null) {
    const delay = t => new Promise(resolve => setTimeout(resolve, t));
    await delay(1000);
    return await waitForMyAssortmentReady();
  }
  return Promise.resolve(offersTable);
}

async function attachEventToOffersList() {
  const offersTable = await waitForMyAssortmentReady();  
  const offersTableObserver = new MutationObserver(mutations => {
    mutations.forEach(mutation => {
      if (mutation.type === 'childList') {
        if (mutation.addedNodes.length) {
          mutation.addedNodes.forEach(addedNode => {
            if (addedNode.nodeName === 'TR') {
              const checkbox = addedNode.querySelector('input[type="checkbox"]');
              if (checkbox && checkbox.dataset.attached === undefined) {
                checkbox.dataset.attached = true;
                checkbox.addEventListener('click', checkboxClick);
                checkbox.nextElementSibling.addEventListener('mouseenter', checkboxMouseEnter);
                checkbox.nextElementSibling.addEventListener('mouseleave', checkboxMouseLeave);
              }
            }
          });
        }
        if (mutation.removedNodes.length) {
          mutation.removedNodes.forEach(removedNode => {
            if (removedNode.nodeName === 'TR' && removedNode.querySelector('input[data-last="true"]')) {
              toastMessage('Usunięto zaznaczenie początkowe');
            }
          });
        }
      }
    });
  });

  const checkboxes = offersTable.querySelectorAll('input[type="checkbox"]');
  checkboxes.forEach(checkbox => {
    if (checkbox && checkbox.dataset.attached === undefined) {
      checkbox.dataset.attached = true;
      checkbox.addEventListener('click', checkboxClick);
      checkbox.nextElementSibling.addEventListener('mouseenter', checkboxMouseEnter);
      checkbox.nextElementSibling.addEventListener('mouseleave', checkboxMouseLeave);
    }
  });

  offersTableObserver.observe(offersTable, { subtree: true, childList: true });
}

function checkboxMouseEnter(e) {
  e.target.dataset.mouseover = true;
}

function checkboxMouseLeave(e) {
  delete e.target.dataset.mouseover;
}

document.addEventListener('selectionchange', (e) => {
  const offersTable = document.querySelector('table[aria-label="lista ofert"]');
  if (!offersTable) return;
  let checkboxMouseOver = offersTable.querySelector('label[data-mouseover="true"]');
  if (checkboxMouseOver) checkboxMouseOver = checkboxMouseOver.previousElementSibling;
  const lastClickedChechbox = offersTable.querySelector('input[data-last="true"]');
  if (checkboxMouseOver && lastClickedChechbox) {
    document.getSelection().removeAllRanges();
  }
});

function checkboxClick(e) {
  const offersTable = document.querySelector('table[aria-label="lista ofert"]');
  const allCheckboxes = Array.from(offersTable.querySelectorAll('input[type="checkbox"]'));
  let checkboxMouseOver = offersTable.querySelector('label[data-mouseover="true"]');
  if (checkboxMouseOver) checkboxMouseOver = checkboxMouseOver.previousElementSibling;
  else return;
  const lastClickedChechbox = offersTable.querySelector('input[data-last="true"]');
  if (lastClickedChechbox === null) {
    checkboxMouseOver.dataset.last = true;
  } else {
    delete lastClickedChechbox.dataset.last;
    checkboxMouseOver.dataset.last = true;
    
    if (e.shiftKey) {
      let startIndex = allCheckboxes.indexOf(lastClickedChechbox);
      let endIndex = allCheckboxes.indexOf(checkboxMouseOver);
      if (startIndex === endIndex) {
        return;
      } else if (startIndex > endIndex) {
        const backupIndex = startIndex;
        startIndex = endIndex;
        endIndex = backupIndex;
      }
      let i, totalItems;
      totalItems = allCheckboxes.length - 1; 
      for (i = 0; i < startIndex; i++) {
        allCheckboxes.shift();
      }
      for (i = totalItems; i > endIndex; i--) {
        allCheckboxes.pop();
      }
      const expectedState = checkboxMouseOver.checked;
      allCheckboxes.forEach(checkbox => {
        if (checkbox.checked !== expectedState) checkbox.click();
      });
    }
  }
}